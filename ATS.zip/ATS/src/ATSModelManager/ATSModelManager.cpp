#include "ATSModelManager.h"
#include <functional>

/************************************************************************
	Constructor / Destructor
************************************************************************/
ATSModelManager::ATSModelManager(void)
{
	init();
}

ATSModelManager::~ATSModelManager(void)
{
	release();
}

void
ATSModelManager::init()
{
	setUserName(_T("ATSModelManager"));

	// by contract
	mec = new MECComponent;
	mec->setUser(this);
}

void
ATSModelManager::release()
{
	meb = nullptr;
	delete mec;
	mec = nullptr;
}

/************************************************************************
	Inherit Function
************************************************************************/
shared_ptr<NOM>
ATSModelManager::registerMsg(tstring msgName)
{
	shared_ptr<NOM> nomMsg = mec->registerMsg(msgName);
	registeredMsg.insert(pair<unsigned int, shared_ptr<NOM>>(nomMsg->getInstanceID(), nomMsg));

	return nomMsg;
}

void
ATSModelManager::discoverMsg(shared_ptr<NOM> nomMsg)
{
	discoveredMsg.insert(pair<unsigned int, shared_ptr<NOM>>(nomMsg->getInstanceID(), nomMsg));
}

void
ATSModelManager::updateMsg(shared_ptr<NOM> nomMsg)
{
	mec->updateMsg(nomMsg);
}

void
ATSModelManager::reflectMsg(shared_ptr<NOM> nomMsg)
{
	// if need be, write your code
}

void
ATSModelManager::deleteMsg(shared_ptr<NOM> nomMsg)
{
	mec->deleteMsg(nomMsg);
	registeredMsg.erase(nomMsg->getInstanceID());
}

void
ATSModelManager::removeMsg(shared_ptr<NOM> nomMsg)
{
	discoveredMsg.erase(nomMsg->getInstanceID());
}

void
ATSModelManager::sendMsg(shared_ptr<NOM> nomMsg)
{
	mec->sendMsg(nomMsg);
}

void
ATSModelManager::recvMsg(shared_ptr<NOM> nomMsg)
{
	// ���� ���� �޽��� ���� 
	/*
	if (nomMsg->getName() == _T("TestControl") && (nomMsg->getValue(_T("Start")))->toShort() == 1) {
		auto SimAckNOM = meb->getNOMInstance(getUserName(), _T("TestControlResponse"));
		SimAckNOM->setValue(_T("MessageHeader.MessageID"), &NUShort(2101));
		SimAckNOM->setValue(_T("MessageHeader.MessageSize"), &NUShort(4));
		SimAckNOM->setValue(_T("Start"), &NUShort(1)); // ���� ���� 
		SimAckNOM->setValue(_T("Response"), &NUShort(1));
		// tmpMsg = SimAckNOM;
		this->sendMsg(SimAckNOM);
		// this->sendMsg(SimAckNOM);
	}
	// ���� ���� �޽��� ����
	else if(nomMsg->getName() == _T("TestControl") && (nomMsg->getValue(_T("Start")))->toShort() == 0) {
		auto SimAckNOM = meb->getNOMInstance(getUserName(), _T("TestControlResponse"));
		SimAckNOM->setValue(_T("MessageHeader.MessageID"), &NUShort(2101));
		SimAckNOM->setValue(_T("MessageHeader.MessageSize"), &NUShort(4));
		SimAckNOM->setValue(_T("Start"), &NUShort(0)); // ���� ���� 
		SimAckNOM->setValue(_T("Response"), &NUShort(1));
		// tmpMsg = SimAckNOM;
		this->sendMsg(SimAckNOM);
		// this->sendMsg(SimAckNOM);
	}*/
	// �ó����� �޾��� �� Ȯ�� �޽��� �۽� 
	/*
	else if (nomMsg->getName() == _T("ScenarioDistribution")) {
		auto ScenarioStart = meb->getNOMInstance(getUserName(), _T("ScenarioResponse"));
		ScenarioStart->setValue(_T("MessageHeader.MessageID"), & NUShort(2102));
		ScenarioStart->setValue(_T("MessageHeader.MessageSize"), & NUShort(4));
		ScenarioStart->setValue(_T("Response"), & NUShort(1));
	}*/
		//this->sendMsg(nomMsg);
	//}
	if (auto itr = msgMethodMap.find(nomMsg->getName()); itr!= msgMethodMap.end()) {
		(itr->second)(nomMsg);
	}
}

void
ATSModelManager::setUserName(tstring userName)
{
	name = userName;
}

tstring
ATSModelManager::getUserName()
{
	return name;
}

void
ATSModelManager::setData(void* data)
{
	// if need be, write your code
}

bool
ATSModelManager::start()
{
	// if need be, write your code
	airThreat = new AirthreatModel;

	// �ó����� ���� �ʾ��� ��� �ʱⰪ
	airThreat->setThreatPosition(1.0, 1.0);
	airThreat->setThreatTargetPosition(10.0, 10.0);

	// binding message

	// �ó����� ���� 
	function<void(shared_ptr<NOM>)> msgProcessor_1;
	msgProcessor_1 = bind(&ATSModelManager::processSettingMsg, this, placeholders::_1);
	msgMethodMap.insert(make_pair(_T("ScenarioDistribution"), msgProcessor_1));

	// ���� ���� �� ���� 
	function<void(shared_ptr<NOM>)> msgProcessor_2;
	msgProcessor_2 = bind(&ATSModelManager::processControlMsg, this, placeholders::_1);
	msgMethodMap.insert(make_pair(_T("TestControl"), msgProcessor_2));

	// �������� �⵿ 
	/*airThreatNOM = this->registerMsg(_T("AirThreatPos"));
	airThreatNOM->setValue(_T("MessageHeader.ID"), &NUShort(2001));
	airThreatNOM->setValue(_T("MessageHeader.SIZE"), &NUShort(4));
	airThreatNOM->setValue(_T("AirThreatPosX"), &NDouble(airThreat->getThreatPosX()));
	airThreatNOM->setValue(_T("AirThreatPosY%"), &NDouble(airThreat->getThreatPosY()));*/

	// object meessage

	//nTimer->addPeriodicTask()

	// ���� ���� 
	//function<void(shared_ptr<NOM>)> msgProcessor;
	//msgProcessor = bind(&ATSModelManager::processStopMsg, this, placeholders::_1);
	//msgMethodMap.insert(make_pair(_T("TestControl"), msgProcessor));
	return true;
}

bool
ATSModelManager::stop()
{
	// if need be, write your code
	delete airThreat;
	timerHandle = 0;
	nTimer = nullptr;

	return true;
}

void
ATSModelManager::setMEBComponent(IMEBComponent* realMEB)
{
	meb = realMEB;
	mec->setMEB(meb);
}

/************************************************************************
	message processor
************************************************************************/

void
ATSModelManager::processSettingMsg(shared_ptr<NOM> nomMsg)
{
	// if need be, write your code

	// �ó����� �޽��� ����
		auto ScenarioNOM = meb->getNOMInstance(getUserName(), _T("ScenarioResponse"));
		ScenarioNOM->setValue(_T("MessageHeader.MessageID"), &NUShort(2102));
		ScenarioNOM->setValue(_T("MessageHeader.MessageSize"), &NUShort(4));
		ScenarioNOM->setValue(_T("Response"), &NUShort(1));
		// tmpMsg = SimAckNOM;
		this->sendMsg(ScenarioNOM);
		// this->sendMsg(SimAckNOM);

	// �ó����� ����
	SimulationSpeed = nomMsg->getValue(_T("Speed"))->toByte();
	auto InitPosX = nomMsg->getValue(_T("ATS.ATSInitPositionX"))->toDouble();
	auto InitPosY = nomMsg->getValue(_T("ATS.ATSInitPositionY"))->toDouble();
	auto targetPosX = nomMsg->getValue(_T("ATS.ATSTargetX"))->toDouble();
	auto targetPosY = nomMsg->getValue(_T("ATS.ATSTargetY"))->toDouble();
	auto velocity = nomMsg->getValue(_T("ATS.ATSVelocity"))->toDouble();
	
	airThreat->setThreatPosition(InitPosX, InitPosY);
	airThreat->setThreatTargetPosition(targetPosX, targetPosY);
	airThreat->setThreatVelocity(velocity);


}

void
ATSModelManager::processControlMsg(shared_ptr<NOM> nomMsg)
{
	// if need be, write your code

	// ���� ���� �޽��� ���� 
	if ((nomMsg->getValue(_T("Start")))->toShort() == 1) {
		auto SimAckNOM = meb->getNOMInstance(getUserName(), _T("TestControlResponse"));
		SimAckNOM->setValue(_T("MessageHeader.MessageID"), &NUShort(2101));
		SimAckNOM->setValue(_T("MessageHeader.MessageSize"), &NUShort(4));
		SimAckNOM->setValue(_T("Start"), &NUShort(1)); // ���� ���� 
		SimAckNOM->setValue(_T("Response"), &NUShort(1));
		// tmpMsg = SimAckNOM;
		this->sendMsg(SimAckNOM);
		// ���� ����
		airThreat->start();
		airThreatNOM = this->registerMsg(_T("AirThreatPos"));
		airThreatNOM->setValue(_T("MessageHeader.MessageID"), &NUShort(2001));
		airThreatNOM->setValue(_T("MessageHeader.MessageSize"), &NUShort(4));
		airThreatNOM->setValue(_T("AirThreatPosX"), &NDouble(airThreat->getThreatPosX()));
		airThreatNOM->setValue(_T("AirThreatPosY"), &NDouble(airThreat->getThreatPosY()));

		nTimer = &(NTimer::getInstance());
		std::function<void(void*)> periodicFunc;
		periodicFunc = std::bind(&ATSModelManager::updateAirThreat, this);
		timerHandle = 0;
		timerHandle = nTimer->addPeriodicTask(1000/SimulationSpeed, periodicFunc);
		// this->sendMsg(SimAckNOM);
	}
	else if ((nomMsg->getValue(_T("Start")))->toShort() == 0) {
		auto SimAckNOM = meb->getNOMInstance(getUserName(), _T("TestControlResponse"));
		SimAckNOM->setValue(_T("MessageHeader.MessageID"), &NUShort(2101));
		SimAckNOM->setValue(_T("MessageHeader.MessageSize"), &NUShort(4));
		SimAckNOM->setValue(_T("Start"), &NUShort(0)); // ���� ���� �ǹ�
		SimAckNOM->setValue(_T("Response"), &NUShort(1));
		// tmpMsg = SimAckNOM;
		this->sendMsg(SimAckNOM);
		// this->sendMsg(SimAckNOM);
		
		// ���� ����
		nTimer->removeTask(timerHandle);
		airThreat->setThreatPosition(0.0, 0.0);
		airThreat->setThreatVelocity(0.0);

	}

}

void
ATSModelManager::updateAirThreat()
{
	airThreatNOM->setValue(_T("AirThreatPosX"), &NDouble(airThreat->getThreatPosX()));
	airThreatNOM->setValue(_T("AirThreatPosY"), &NDouble(airThreat->getThreatPosY()));
	mec->updateMsg(airThreatNOM);
}


void
ATSModelManager::processStopMsg(shared_ptr<NOM> nomMsg)
{
	// if need be, write your code

	
}

/*
void
ATSModelManager::sendPeriodically(shared_ptr<NOM> nomMsg)
{
	// nomMsg->setValue(_T("AirThreatPosX"), &DOUBLE(2.0));
}*/

/************************************************************************
	Export Function
************************************************************************/
extern "C" BASEMGRDLL_API
BaseManager * createObject()
{
	return new ATSModelManager;
}

extern "C" BASEMGRDLL_API
void deleteObject(BaseManager * userManager)
{
	delete userManager;
}

