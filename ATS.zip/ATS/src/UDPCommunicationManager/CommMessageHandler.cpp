#include "CommMessageHandler.h"

/************************************************************************
	initialize / release
************************************************************************/
CommMessageHandler::CommMessageHandler()
{
	initialize();
}

CommMessageHandler::~CommMessageHandler()
{
	release();
}

void
CommMessageHandler::initialize()
{
	// if need be, write your code
	// Rule : abxx (a : �۽�ó / b : �޽��� ���� (object / interaction) / xx : �ĺ� ��ȣ)
   // OCC interaction
	setIDNameTable(1101, _T("TestControl"));
	setIDNameTable(1102, _T("ScenarioDistribution"));

	// ����-���� ���� ���� (ATS -> OCC)
	setIDNameTable(2101, _T("TestControlResponse"));

	// �ó����� ���� (SIM -> OCC)
	setIDNameTable(2102, _T("ScenarioResponse"));

	// ATS ���� ���� ��ü ��ġ
	setIDNameTable(2001, _T("AirThreatPos"));


}

void
CommMessageHandler::release()
{
	IDNameTable.clear();
}

/************************************************************************
	ID_Name table management
************************************************************************/
void
CommMessageHandler::setIDNameTable(unsigned short msgID, tstring msgName)
{
	IDNameTable.insert(pair<unsigned short, tstring>(msgID, msgName));
}

tstring
CommMessageHandler::getMsgName(unsigned short msgID)
{
	tstring msgName;
	if (auto itr = IDNameTable.find(msgID); itr != IDNameTable.end())
	{
		msgName = itr->second;
	}
	else
	{
		msgName = _T("");
	}

	return msgName;
}